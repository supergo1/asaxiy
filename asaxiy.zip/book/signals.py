from django.db.models.signals import pre_delete


# def before_delete(sig)